$(() => {
    $("#article-table tr:odd").css("background-color", "lightgray");
});